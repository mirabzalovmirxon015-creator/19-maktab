# 🚀 Tezkor Boshlash Qo'llanmasi

## 1. Direktor Hisobini Yaratish

### Supabase Dashboard orqali:

1. **Supabase-ga kiring**
   - https://supabase.com/dashboard ga o'ting
   - Loyihangizni tanlang

2. **User yarating**
   - Chap menuda **Authentication** → **Users** ni bosing
   - **Add User** tugmasini bosing
   - Email: `director@19maktab.uz`
   - Password: `19!maktab!`
   - **Create User** tugmasini bosing

3. **Tayyor!** Endi tizimga kirishingiz mumkin

## 2. Saytga Kirish

1. Brauzeringizda saytni oching
2. **Admin** tugmasini bosing
3. Login va parolni kiriting:
   - Login: `director@19maktab.uz`
   - Parol: `19!maktab!`
4. **Kirish** tugmasini bosing

## 3. Birinchi Yangilik Qo'shish

1. Admin panelda **Yangiliklar** bo'limida bo'lishingizni tekshiring
2. **Yangilik qo'shish** tugmasini bosing
3. Ma'lumotlarni to'ldiring:
   - **Sarlavha**: Yangilik sarlavhasi
   - **Matn**: To'liq yangilik matni
   - **Rasm URL**: Pexels.com dan rasm topib, URL kiriting
     - Masalan: `https://images.pexels.com/photos/289737/pexels-photo-289737.jpeg?auto=compress&cs=tinysrgb&w=1920`
4. **Saqlash** tugmasini bosing

## 4. Fotogalereya-ga Rasm Qo'shish

1. **Fotogalereya** tabini tanlang
2. **Rasm qo'shish** tugmasini bosing
3. Ma'lumotlarni kiriting:
   - **Rasm URL**: Pexels.com dan rasm URL
   - **Izoh**: Rasm haqida qisqacha (ixtiyoriy)
4. **Saqlash** tugmasini bosing

## 5. Dars Jadvali Qo'shish

1. **Dars jadvali** tabini tanlang
2. **Jadval qo'shish** tugmasini bosing
3. Ma'lumotlarni to'ldiring:
   - **Sinf nomi**: Masalan: `1-A sinf`
   - **Jadval ma'lumotlari**: JSON formatda (quyida misol)

### Jadval JSON Misoli:

```json
{
  "lessons": [
    {
      "monday": "Matematika",
      "tuesday": "Ona tili",
      "wednesday": "Ingliz tili",
      "thursday": "Tarix",
      "friday": "Fizika",
      "saturday": "Kimyo"
    },
    {
      "monday": "Ona tili",
      "tuesday": "Matematika",
      "wednesday": "Geografiya",
      "thursday": "Biologiya",
      "friday": "Adabiyot",
      "saturday": "Informatika"
    }
  ]
}
```

4. **Saqlash** tugmasini bosing

## 6. Slider Rasm Qo'shish

1. **Slider** tabini tanlang
2. **Slider qo'shish** tugmasini bosing
3. Ma'lumotlarni kiriting:
   - **Rasm URL**: To'liq ekran rasm URL
   - **Matn**: Slider ustida ko'rinadigan matn
   - **Tartib raqami**: 1, 2, 3... (qaysi tartibda ko'rinishi)
4. **Saqlash** tugmasini bosing

## 7. Statistika Yangilash

1. **Statistika** tabini tanlang
2. Istalgan statistika blokiga bosing
3. Prompt oynasida yangi qiymat kiriting
4. **OK** tugmasini bosing

## 8. Saytni Ko'rish

1. Admin panelda yuqori o'ng burchakda **Saytga qaytish** tugmasini bosing
2. Yoki header-dagi sahifalar orqali navigatsiya qiling

## 9. Chiqish

1. Admin panelda **Chiqish** tugmasini bosing (yuqori o'ng burchak)

## ⚡ Tezkor Maslahatlar

### Rasmlar uchun:
- **Pexels.com** - bepul professional rasmlar
- **Unsplash.com** - bepul yuqori sifatli rasmlar
- Rasm URL ni to'g'ri nusxa oling (right click → Copy image address)

### Yangiliklar uchun:
- Qisqa va aniq sarlavhalar yozing
- Matnni paragraflar bilan ajrating (Enter bosing)
- Muhim ma'lumotlarni birinchi qo'ying

### Jadvallar uchun:
- `schedule-example.json` faylidan nusxa olib ishlatishingiz mumkin
- Har bir dars nomini to'g'ri yozing
- Bo'sh dars uchun `-` belgisini qo'ying

### Slider uchun:
- Yirik va yuqori sifatli rasmlar ishlating (1920x1080 yoki kattaroq)
- Matnni qisqa va ta'sirli qiling
- 3-5 ta slider yetarli

## 🆘 Muammolar?

### Login qila olmayapman
- Email va parol to'g'riligini tekshiring
- Supabase-da user yaratilganligini tekshiring
- Brauzer cache-ni tozalang

### Rasm ko'rinmayapti
- URL to'g'riligini tekshiring
- Rasm ochiq (public) ekanligini tekshiring
- To'g'ridan-to'g'ri rasm URL ekanligini tekshiring

### Jadval xato beradi
- JSON formatni tekshiring
- Barcha `"` (qo'shtirnoq) to'g'ri yopilganligini tekshiring
- Oxirgi elementdan keyin vergul qo'ymang

## 📞 Yordam

Agar muammolar davom etsa:
1. README.md faylini o'qing
2. FEATURES.md faylida batafsil ma'lumot bor
3. SETUP.md faylida texnik ma'lumotlar

---

**Muvaffaqiyatlar! 🎉**

Saytingiz tayyor va ishlatishga tayyordir. Yangiliklar, rasmlar va jadvallarni muntazam yangilab turing!
