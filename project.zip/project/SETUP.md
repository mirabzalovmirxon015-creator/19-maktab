# 19-maktab Web Sayt - O'rnatish Yo'riqnomasi

## Direktor hisobi yaratish

Saytning admin paneliga kirish uchun direktor hisobini yaratish kerak:

### 1-usul: Supabase Dashboard orqali

1. Supabase Dashboard-ga kiring: https://supabase.com/dashboard
2. O'z proyektingizni tanlang
3. Authentication → Users ga o'ting
4. "Add User" tugmasini bosing
5. Quyidagi ma'lumotlarni kiriting:
   - **Email**: `director@19maktab.uz`
   - **Password**: `19!maktab!`
6. "Create User" tugmasini bosing

### 2-usul: SQL orqali

Supabase SQL Editor-da quyidagi buyruqni bajarishingiz mumkin:

```sql
-- MUHIM: Avval Supabase Dashboard-da oddiy usulda yarating
-- Bu usul faqat texnik xodimlar uchun
```

## Kirish ma'lumotlari

Direktor quyidagi ma'lumotlar bilan tizimga kira oladi:

- **Login (Email)**: `director@19maktab.uz`
- **Parol**: `19!maktab!`

## Loyihani ishga tushirish

```bash
# Paketlarni o'rnatish
npm install

# Ishlab chiqish rejimida ishga tushirish
npm run dev

# Ishlab chiqarish uchun build qilish
npm run build
```

## Admin panel imkoniyatlari

Direktor admin panelda quyidagilarni boshqara oladi:

1. **Yangiliklar** - Yangilik qo'shish, tahrirlash va o'chirish
2. **Fotogalereya** - Rasmlar yuklash va boshqarish
3. **Dars jadvali** - Sinflar bo'yicha jadval yaratish va boshqarish
4. **Slider** - Bosh sahifadagi slider rasmlarini boshqarish
5. **Statistika** - Sayt statistikalarini yangilash

## Texnik ma'lumotlar

- **Frontend**: React + TypeScript + Vite
- **Styling**: Tailwind CSS
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **Icons**: Lucide React

## Muammolar va yechimlar

Agar login qilishda muammo bo'lsa:

1. Supabase loyihangiz ishga tushganligini tekshiring
2. `.env` faylidagi ma'lumotlar to'g'riligini tekshiring
3. Direktor hisobi yaratilganligini tekshiring
4. Email va parol to'g'ri kiritilganligini tekshiring

## Qo'shimcha

Sayt to'liq responsive va barcha qurilmalarda ishlaydi. Admin panel qorong'i (dark mode) dizaynda ishlangan.
