# Loyiha Strukturasi

## 📁 Papka va Fayllar

```
19-maktab/
│
├── 📄 README.md                    # Asosiy hujjat
├── 📄 SETUP.md                     # O'rnatish yo'riqnomasi
├── 📄 FEATURES.md                  # To'liq xususiyatlar ro'yxati
├── 📄 QUICK-START.md               # Tezkor boshlash
├── 📄 PROJECT-STRUCTURE.md         # Bu fayl
├── 📄 schedule-example.json        # Jadval misoli
│
├── 📁 src/                         # Manba kodlar
│   ├── 📁 components/              # React komponentlar
│   │   ├── Header.tsx              # Navigatsiya
│   │   └── Footer.tsx              # Footer
│   │
│   ├── 📁 pages/                   # Sahifalar
│   │   ├── Home.tsx                # Bosh sahifa
│   │   ├── About.tsx               # Biz haqimizda
│   │   ├── News.tsx                # Yangiliklar
│   │   ├── Gallery.tsx             # Fotogalereya
│   │   ├── Schedule.tsx            # Dars jadvali
│   │   ├── Contact.tsx             # Aloqa
│   │   ├── Login.tsx               # Kirish sahifasi
│   │   └── Admin.tsx               # Admin panel
│   │
│   ├── 📁 contexts/                # React Context
│   │   └── AuthContext.tsx         # Autentifikatsiya
│   │
│   ├── 📁 lib/                     # Kutubxonalar
│   │   └── supabase.ts             # Supabase client
│   │
│   ├── 📁 types/                   # TypeScript types
│   │   └── database.ts             # Database types
│   │
│   ├── App.tsx                     # Asosiy komponent
│   ├── main.tsx                    # Entry point
│   └── index.css                   # Tailwind CSS
│
├── 📁 public/                      # Static fayllar
│   └── vite.svg                    # Logo
│
├── 📄 index.html                   # HTML shablon
├── 📄 .env                         # Environment variables
├── 📄 package.json                 # Dependencies
├── 📄 tsconfig.json                # TypeScript config
├── 📄 vite.config.ts               # Vite config
├── 📄 tailwind.config.js           # Tailwind config
└── 📄 postcss.config.js            # PostCSS config
```

## 🗄️ Ma'lumotlar Bazasi

### Supabase Tables

1. **news** - Yangiliklar jadvali
   ```sql
   - id (uuid, primary key)
   - title (text)
   - content (text)
   - image_url (text, nullable)
   - created_at (timestamptz)
   - updated_at (timestamptz)
   ```

2. **gallery** - Fotogalereya jadvali
   ```sql
   - id (uuid, primary key)
   - image_url (text)
   - caption (text)
   - created_at (timestamptz)
   ```

3. **schedule** - Dars jadvali
   ```sql
   - id (uuid, primary key)
   - class_name (text, unique)
   - schedule_data (jsonb)
   - created_at (timestamptz)
   - updated_at (timestamptz)
   ```

4. **slider** - Bosh sahifa slider
   ```sql
   - id (uuid, primary key)
   - image_url (text)
   - caption (text)
   - order_index (integer)
   - active (boolean)
   - created_at (timestamptz)
   ```

5. **statistics** - Statistika
   ```sql
   - id (uuid, primary key)
   - key (text, unique)
   - value (text)
   - label (text)
   - icon (text)
   - created_at (timestamptz)
   ```

## 🎨 Komponentlar Tafsiloti

### Header.tsx (266 qator)
- Responsive navigatsiya
- Mobil hamburger menu
- Logo va brend
- Aktiv sahifa ko'rsatkichi
- Admin tugmasi

### Footer.tsx (46 qator)
- Maktab ma'lumotlari
- Aloqa ma'lumotlari
- Ijtimoiy tarmoqlar
- Copyright

### Home.tsx (180 qator)
- Avtomatik slider
- Statistika bloklari
- So'nggi yangiliklar
- Real-time ma'lumotlar

### About.tsx (135 qator)
- Maktab tarixi
- Afzalliklar
- Maqsadlar
- Yutuqlar

### News.tsx (130 qator)
- Yangiliklar ro'yxati
- To'liq yangilik ko'rinishi
- Grid layout
- Sana formatlash

### Gallery.tsx (95 qator)
- Rasmlar gridi
- Lightbox
- Hover effektlar
- Caption ko'rinishi

### Schedule.tsx (120 qator)
- Sinf tanlash
- Jadval ko'rinishi
- Responsive jadval
- JSON parsing

### Contact.tsx (115 qator)
- Aloqa ma'lumotlari
- Xabar formasi
- Google Maps
- Icon'lar

### Login.tsx (85 qator)
- Login formasi
- Parol kiritish
- Xato xabarlari
- Gradient dizayni

### Admin.tsx (680+ qator)
- Dark mode dizayni
- 5 ta tab (Yangiliklar, Gallery, Schedule, Slider, Statistics)
- CRUD operatsiyalar
- Form validation
- Confirm dialogs
- Real-time yangilanishlar

## 🔐 Autentifikatsiya

### AuthContext.tsx (65 qator)
- Supabase Auth integratsiyasi
- User state management
- Sign in funksiyasi
- Sign out funksiyasi
- Session tracking

## 📦 Dependencies

### Production
- `react` - UI framework
- `react-dom` - React DOM renderer
- `@supabase/supabase-js` - Supabase client
- `lucide-react` - Icon library

### Development
- `typescript` - Type safety
- `vite` - Build tool
- `tailwindcss` - CSS framework
- `eslint` - Code linting
- `@vitejs/plugin-react` - React plugin

## 🎯 Funksiyalar Soni

### Komponentlar: 12 ta
- Header
- Footer
- Home
- About
- News
- Gallery
- Schedule
- Contact
- Login
- Admin
- AuthContext
- App

### Sahifalar: 6 ta
- Bosh sahifa
- Biz haqimizda
- Yangiliklar
- Fotogalereya
- Dars jadvali
- Aloqa

### Admin Funksiyalar: 5 ta
1. Yangiliklar boshqaruvi
2. Fotogalereya boshqaruvi
3. Dars jadvali boshqaruvi
4. Slider boshqaruvi
5. Statistika boshqaruvi

## 📊 Statistika

### Umumiy:
- **Komponentlar**: 12 ta
- **Sahifalar**: 6 ta (public) + 2 ta (admin)
- **Database Tables**: 5 ta
- **Kod qatorlari**: ~2500+ qator
- **TypeScript fayllar**: 14 ta
- **CSS**: Tailwind (utility-first)

### Xususiyatlar:
- ✅ Responsive dizayn
- ✅ Dark mode (admin)
- ✅ Authentication
- ✅ Database CRUD
- ✅ Real-time updates
- ✅ Image gallery
- ✅ Slider
- ✅ Forms
- ✅ Validation
- ✅ Error handling

## 🚀 Build Ma'lumotlari

```
dist/
├── index.html (0.87 KB)
├── assets/
│   ├── index-Cm8Lkj6d.css (17.98 KB → 3.98 KB gzip)
│   └── index-Cp03g7-Z.js (322.82 KB → 90.31 KB gzip)
```

**Jami hajm**: ~91 KB (gzip)

## 🎓 Texnologiyalar

### Frontend
- **Framework**: React 18.3.1
- **Language**: TypeScript 5.5.3
- **Styling**: Tailwind CSS 3.4.1
- **Build**: Vite 5.4.2
- **Icons**: Lucide React 0.344.0

### Backend
- **Database**: Supabase (PostgreSQL)
- **Auth**: Supabase Auth
- **API**: Supabase REST API

### Tools
- **Linter**: ESLint 9.9.1
- **Package Manager**: npm

## 📝 Hujjatlar

1. **README.md** - Asosiy hujjat va umumiy ma'lumot
2. **SETUP.md** - O'rnatish va sozlash yo'riqnomasi
3. **FEATURES.md** - Barcha xususiyatlar batafsil
4. **QUICK-START.md** - Tezkor boshlash qo'llanmasi
5. **PROJECT-STRUCTURE.md** - Loyiha strukturasi (bu fayl)

## ✨ Asosiy Afzalliklar

1. **Zamonaviy Texnologiyalar**
   - React 18, TypeScript, Tailwind CSS
   - Vite (tez build)
   - Supabase (zamonaviy backend)

2. **Professional Dizayn**
   - Ko'k + Oq rang sxemasi
   - Responsive layout
   - Dark mode admin panel
   - Smooth animations

3. **Foydalanish Oson**
   - Intuitiv interfeys
   - Clear navigation
   - Helpful error messages
   - Loading states

4. **Xavfsiz**
   - Supabase Auth
   - Row Level Security
   - Password protection
   - Session management

5. **Kengaytiriladigan**
   - Modular struktura
   - TypeScript types
   - Reusable components
   - Clear documentation

---

Bu loyiha to'liq professional, zamonaviy va ishlab chiqarish uchun tayyor web-saytdir.
