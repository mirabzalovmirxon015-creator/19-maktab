import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { News } from './pages/News';
import { Gallery } from './pages/Gallery';
import { Schedule } from './pages/Schedule';
import { Contact } from './pages/Contact';
import { Login } from './pages/Login';
import { Admin } from './pages/Admin';

function AppContent() {
  const [currentPage, setCurrentPage] = useState('home');
  const { user } = useAuth();

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };

  if (currentPage === 'admin') {
    if (!user) {
      return <Login onLoginSuccess={() => setCurrentPage('admin')} />;
    }
    return <Admin onBack={() => setCurrentPage('home')} />;
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header currentPage={currentPage} onNavigate={handleNavigate} />
      <main className="flex-1">
        {currentPage === 'home' && <Home onNavigate={handleNavigate} />}
        {currentPage === 'about' && <About />}
        {currentPage === 'news' && <News />}
        {currentPage === 'gallery' && <Gallery />}
        {currentPage === 'schedule' && <Schedule />}
        {currentPage === 'contact' && <Contact />}
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
