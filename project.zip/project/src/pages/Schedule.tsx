import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

interface ScheduleItem {
  id: string;
  class_name: string;
  schedule_data: Record<string, unknown>;
}

export function Schedule() {
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [selectedClass, setSelectedClass] = useState<string>('');

  useEffect(() => {
    loadSchedules();
  }, []);

  const loadSchedules = async () => {
    const { data } = await supabase
      .from('schedule')
      .select('*')
      .order('class_name');
    if (data) {
      setSchedules(data);
      if (data.length > 0) setSelectedClass(data[0].class_name);
    }
  };

  const selectedSchedule = schedules.find((s) => s.class_name === selectedClass);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center">Dars jadvali</h1>

      {schedules.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          Hozircha dars jadvali yo'q
        </div>
      ) : (
        <>
          <div className="mb-6 flex flex-wrap gap-2 justify-center">
            {schedules.map((schedule) => (
              <button
                key={schedule.id}
                onClick={() => setSelectedClass(schedule.class_name)}
                className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                  selectedClass === schedule.class_name
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-blue-50'
                } shadow-md`}
              >
                {schedule.class_name}
              </button>
            ))}
          </div>

          {selectedSchedule && (
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="bg-blue-600 text-white p-4">
                <h2 className="text-2xl font-bold text-center">{selectedSchedule.class_name}</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-3 text-left font-semibold text-gray-700">Dars</th>
                      <th className="px-4 py-3 text-left font-semibold text-gray-700">Dushanba</th>
                      <th className="px-4 py-3 text-left font-semibold text-gray-700">Seshanba</th>
                      <th className="px-4 py-3 text-left font-semibold text-gray-700">Chorshanba</th>
                      <th className="px-4 py-3 text-left font-semibold text-gray-700">Payshanba</th>
                      <th className="px-4 py-3 text-left font-semibold text-gray-700">Juma</th>
                      <th className="px-4 py-3 text-left font-semibold text-gray-700">Shanba</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.isArray(selectedSchedule.schedule_data.lessons) ? (
                      (selectedSchedule.schedule_data.lessons as Array<Record<string, string>>).map((lesson, index) => (
                        <tr key={index} className="border-t border-gray-200 hover:bg-gray-50">
                          <td className="px-4 py-3 font-semibold text-gray-700">{index + 1}</td>
                          <td className="px-4 py-3 text-gray-600">{lesson.monday || '-'}</td>
                          <td className="px-4 py-3 text-gray-600">{lesson.tuesday || '-'}</td>
                          <td className="px-4 py-3 text-gray-600">{lesson.wednesday || '-'}</td>
                          <td className="px-4 py-3 text-gray-600">{lesson.thursday || '-'}</td>
                          <td className="px-4 py-3 text-gray-600">{lesson.friday || '-'}</td>
                          <td className="px-4 py-3 text-gray-600">{lesson.saturday || '-'}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={7} className="px-4 py-8 text-center text-gray-500">
                          Jadval ma'lumotlari noto'g'ri formatda
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
