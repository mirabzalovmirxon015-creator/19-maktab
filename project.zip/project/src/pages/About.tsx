import { Award, BookOpen, Users, Target } from 'lucide-react';

export function About() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center">Biz haqimizda</h1>

      <div className="bg-white rounded-lg shadow-lg p-8 mb-12">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <img
              src="https://images.pexels.com/photos/8500409/pexels-photo-8500409.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Maktab"
              className="rounded-lg shadow-md w-full"
            />
          </div>
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">19-maktab</h2>
            <p className="text-gray-700 mb-4 leading-relaxed">
              19-maktab 1999-yilda tashkil etilgan bo'lib, bugungi kunda O'zbekistonning eng yaxshi
              ta'lim muassasalaridan biri hisoblanadi. Biz 25 yildan ortiq vaqt davomida minglab
              o'quvchilarga sifatli ta'lim berib kelmoqdamiz.
            </p>
            <p className="text-gray-700 mb-4 leading-relaxed">
              Maktabimizda zamonaviy ta'lim texnologiyalari, malakali pedagog kadrlar va qulay
              o'quv muhiti ta'minlangan. Biz har bir o'quvchining individual qobiliyatlarini
              rivojlantirishga alohida e'tibor beramiz.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Bizning maqsadimiz - kelajakka ishonch bilan qadam qo'yuvchi, bilimli va
              ma'naviy barkamol yoshlarni tarbiyalash.
            </p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <div className="bg-white rounded-lg shadow-lg p-6 text-center hover:shadow-xl transition-shadow">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
              <Target size={32} className="text-blue-600" />
            </div>
          </div>
          <h3 className="font-bold text-lg mb-2 text-gray-900">Maqsadimiz</h3>
          <p className="text-gray-600 text-sm">
            Kelajakka ishonch bilan qadam qo'yuvchi, bilimli yoshlarni tarbiyalash
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 text-center hover:shadow-xl transition-shadow">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
              <BookOpen size={32} className="text-blue-600" />
            </div>
          </div>
          <h3 className="font-bold text-lg mb-2 text-gray-900">Zamonaviy ta'lim</h3>
          <p className="text-gray-600 text-sm">
            Eng so'nggi ta'lim texnologiyalari va usullaridan foydalanish
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 text-center hover:shadow-xl transition-shadow">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
              <Users size={32} className="text-blue-600" />
            </div>
          </div>
          <h3 className="font-bold text-lg mb-2 text-gray-900">Malakali kadrlar</h3>
          <p className="text-gray-600 text-sm">
            Yuqori malakali va tajribali pedagog xodimlar jamoasi
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 text-center hover:shadow-xl transition-shadow">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
              <Award size={32} className="text-blue-600" />
            </div>
          </div>
          <h3 className="font-bold text-lg mb-2 text-gray-900">Yutuqlar</h3>
          <p className="text-gray-600 text-sm">
            Ko'plab respublika va xalqaro olimpiadalarda g'oliblar
          </p>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg shadow-lg p-8 text-white">
        <h2 className="text-3xl font-bold mb-6 text-center">Bizning afzalliklarimiz</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white bg-opacity-10 rounded-lg p-6 backdrop-blur-sm">
            <h3 className="font-bold text-xl mb-3">Zamonaviy jihozlar</h3>
            <p className="text-blue-50">
              Barcha sinflar zamonaviy ta'lim jihozlari, kompyuter va internet bilan ta'minlangan
            </p>
          </div>
          <div className="bg-white bg-opacity-10 rounded-lg p-6 backdrop-blur-sm">
            <h3 className="font-bold text-xl mb-3">Qo'shimcha darslar</h3>
            <p className="text-blue-50">
              Sport, san'at, tillar va boshqa ko'plab qo'shimcha ta'lim yo'nalishlari
            </p>
          </div>
          <div className="bg-white bg-opacity-10 rounded-lg p-6 backdrop-blur-sm">
            <h3 className="font-bold text-xl mb-3">Xavfsizlik</h3>
            <p className="text-blue-50">
              24/7 qo'riqlanuvchi hudud, video kuzatuv va xavfsizlik tizimi
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
