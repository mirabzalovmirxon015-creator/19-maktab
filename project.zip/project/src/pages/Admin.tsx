import { useState, useEffect } from 'react';
import {
  Newspaper,
  Image as ImageIcon,
  Calendar,
  BarChart3,
  ImagePlus,
  LogOut,
  Plus,
  Trash2,
  Edit,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface News {
  id: string;
  title: string;
  content: string;
  image_url: string | null;
  created_at: string;
}

interface GalleryItem {
  id: string;
  image_url: string;
  caption: string;
}

interface ScheduleItem {
  id: string;
  class_name: string;
  schedule_data: Record<string, unknown>;
}

interface Slider {
  id: string;
  image_url: string;
  caption: string;
  order_index: number;
  active: boolean;
}

interface Statistic {
  id: string;
  key: string;
  value: string;
  label: string;
  icon: string;
}

export function Admin({ onBack }: { onBack: () => void }) {
  const { signOut } = useAuth();
  const [activeTab, setActiveTab] = useState('news');
  const [news, setNews] = useState<News[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [sliders, setSliders] = useState<Slider[]>([]);
  const [statistics, setStatistics] = useState<Statistic[]>([]);

  const [showNewsForm, setShowNewsForm] = useState(false);
  const [editingNews, setEditingNews] = useState<News | null>(null);
  const [newsForm, setNewsForm] = useState({ title: '', content: '', image_url: '' });

  const [showGalleryForm, setShowGalleryForm] = useState(false);
  const [galleryForm, setGalleryForm] = useState({ image_url: '', caption: '' });

  const [showScheduleForm, setShowScheduleForm] = useState(false);
  const [scheduleForm, setScheduleForm] = useState({ class_name: '', schedule_json: '' });

  const [showSliderForm, setShowSliderForm] = useState(false);
  const [sliderForm, setSliderForm] = useState({ image_url: '', caption: '', order_index: 0 });

  const [editingStat, setEditingStat] = useState<Statistic | null>(null);

  useEffect(() => {
    loadData();
  }, [activeTab]);

  const loadData = async () => {
    if (activeTab === 'news') {
      const { data } = await supabase.from('news').select('*').order('created_at', { ascending: false });
      if (data) setNews(data);
    } else if (activeTab === 'gallery') {
      const { data } = await supabase.from('gallery').select('*').order('created_at', { ascending: false });
      if (data) setGallery(data);
    } else if (activeTab === 'schedule') {
      const { data } = await supabase.from('schedule').select('*').order('class_name');
      if (data) setSchedules(data);
    } else if (activeTab === 'slider') {
      const { data } = await supabase.from('slider').select('*').order('order_index');
      if (data) setSliders(data);
    } else if (activeTab === 'statistics') {
      const { data } = await supabase.from('statistics').select('*');
      if (data) setStatistics(data);
    }
  };

  const handleNewsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingNews) {
      await supabase
        .from('news')
        .update({ ...newsForm, updated_at: new Date().toISOString() })
        .eq('id', editingNews.id);
    } else {
      await supabase.from('news').insert([newsForm]);
    }
    setShowNewsForm(false);
    setEditingNews(null);
    setNewsForm({ title: '', content: '', image_url: '' });
    loadData();
  };

  const handleDeleteNews = async (id: string) => {
    if (confirm('Bu yangilikni o\'chirmoqchimisiz?')) {
      await supabase.from('news').delete().eq('id', id);
      loadData();
    }
  };

  const handleGallerySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await supabase.from('gallery').insert([galleryForm]);
    setShowGalleryForm(false);
    setGalleryForm({ image_url: '', caption: '' });
    loadData();
  };

  const handleDeleteGallery = async (id: string) => {
    if (confirm('Bu rasmni o\'chirmoqchimisiz?')) {
      await supabase.from('gallery').delete().eq('id', id);
      loadData();
    }
  };

  const handleScheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const scheduleData = JSON.parse(scheduleForm.schedule_json);
      await supabase.from('schedule').insert([{
        class_name: scheduleForm.class_name,
        schedule_data: scheduleData,
      }]);
      setShowScheduleForm(false);
      setScheduleForm({ class_name: '', schedule_json: '' });
      loadData();
    } catch (error) {
      alert('JSON formati noto\'g\'ri!');
    }
  };

  const handleDeleteSchedule = async (id: string) => {
    if (confirm('Bu jadvalni o\'chirmoqchimisiz?')) {
      await supabase.from('schedule').delete().eq('id', id);
      loadData();
    }
  };

  const handleSliderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await supabase.from('slider').insert([{ ...sliderForm, active: true }]);
    setShowSliderForm(false);
    setSliderForm({ image_url: '', caption: '', order_index: 0 });
    loadData();
  };

  const handleDeleteSlider = async (id: string) => {
    if (confirm('Bu sliderni o\'chirmoqchimisiz?')) {
      await supabase.from('slider').delete().eq('id', id);
      loadData();
    }
  };

  const handleUpdateStatistic = async (stat: Statistic) => {
    const newValue = prompt('Yangi qiymatni kiriting:', stat.value);
    if (newValue !== null) {
      await supabase.from('statistics').update({ value: newValue }).eq('id', stat.id);
      loadData();
    }
  };

  const handleLogout = async () => {
    await signOut();
    onBack();
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                19
              </div>
              <h1 className="text-xl font-bold text-white">Admin Panel</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-gray-300 hover:text-white transition-colors"
              >
                Saytga qaytish
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                <LogOut size={20} />
                <span>Chiqish</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex space-x-4 mb-6 overflow-x-auto">
          {[
            { id: 'news', label: 'Yangiliklar', icon: Newspaper },
            { id: 'gallery', label: 'Fotogalereya', icon: ImageIcon },
            { id: 'schedule', label: 'Dars jadvali', icon: Calendar },
            { id: 'slider', label: 'Slider', icon: ImagePlus },
            { id: 'statistics', label: 'Statistika', icon: BarChart3 },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                <Icon size={20} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {activeTab === 'news' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Yangiliklar boshqaruvi</h2>
              <button
                onClick={() => {
                  setShowNewsForm(true);
                  setEditingNews(null);
                  setNewsForm({ title: '', content: '', image_url: '' });
                }}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus size={20} />
                <span>Yangilik qo'shish</span>
              </button>
            </div>

            {showNewsForm && (
              <div className="bg-gray-800 rounded-lg p-6 mb-6">
                <h3 className="text-xl font-bold text-white mb-4">
                  {editingNews ? 'Yangilikni tahrirlash' : 'Yangi yangilik'}
                </h3>
                <form onSubmit={handleNewsSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Sarlavha</label>
                    <input
                      type="text"
                      value={newsForm.title}
                      onChange={(e) => setNewsForm({ ...newsForm, title: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Matn</label>
                    <textarea
                      value={newsForm.content}
                      onChange={(e) => setNewsForm({ ...newsForm, content: e.target.value })}
                      rows={6}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600"
                      required
                    ></textarea>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Rasm URL</label>
                    <input
                      type="url"
                      value={newsForm.image_url}
                      onChange={(e) => setNewsForm({ ...newsForm, image_url: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600"
                      placeholder="https://example.com/image.jpg"
                    />
                  </div>
                  <div className="flex space-x-4">
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Saqlash
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowNewsForm(false);
                        setEditingNews(null);
                      }}
                      className="px-6 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
                    >
                      Bekor qilish
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="grid gap-4">
              {news.map((item) => (
                <div key={item.id} className="bg-gray-800 rounded-lg p-4 flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white mb-2">{item.title}</h3>
                    <p className="text-gray-400 text-sm line-clamp-2 mb-2">{item.content}</p>
                    <p className="text-gray-500 text-xs">
                      {new Date(item.created_at).toLocaleDateString('uz-UZ')}
                    </p>
                  </div>
                  <div className="flex space-x-2 ml-4">
                    <button
                      onClick={() => {
                        setEditingNews(item);
                        setNewsForm({
                          title: item.title,
                          content: item.content,
                          image_url: item.image_url || '',
                        });
                        setShowNewsForm(true);
                      }}
                      className="p-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                    >
                      <Edit size={18} />
                    </button>
                    <button
                      onClick={() => handleDeleteNews(item.id)}
                      className="p-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'gallery' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Fotogalereya boshqaruvi</h2>
              <button
                onClick={() => setShowGalleryForm(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus size={20} />
                <span>Rasm qo'shish</span>
              </button>
            </div>

            {showGalleryForm && (
              <div className="bg-gray-800 rounded-lg p-6 mb-6">
                <h3 className="text-xl font-bold text-white mb-4">Yangi rasm</h3>
                <form onSubmit={handleGallerySubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Rasm URL</label>
                    <input
                      type="url"
                      value={galleryForm.image_url}
                      onChange={(e) => setGalleryForm({ ...galleryForm, image_url: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600"
                      placeholder="https://example.com/image.jpg"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Izoh (ixtiyoriy)</label>
                    <input
                      type="text"
                      value={galleryForm.caption}
                      onChange={(e) => setGalleryForm({ ...galleryForm, caption: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600"
                      placeholder="Rasm haqida qisqacha"
                    />
                  </div>
                  <div className="flex space-x-4">
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Saqlash
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowGalleryForm(false)}
                      className="px-6 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
                    >
                      Bekor qilish
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {gallery.map((item) => (
                <div key={item.id} className="relative group">
                  <img
                    src={item.image_url}
                    alt={item.caption}
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                    <button
                      onClick={() => handleDeleteGallery(item.id)}
                      className="p-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                  {item.caption && (
                    <p className="text-gray-300 text-sm mt-2">{item.caption}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'schedule' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Dars jadvali boshqaruvi</h2>
              <button
                onClick={() => setShowScheduleForm(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus size={20} />
                <span>Jadval qo'shish</span>
              </button>
            </div>

            {showScheduleForm && (
              <div className="bg-gray-800 rounded-lg p-6 mb-6">
                <h3 className="text-xl font-bold text-white mb-4">Yangi jadval</h3>
                <form onSubmit={handleScheduleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Sinf nomi</label>
                    <input
                      type="text"
                      value={scheduleForm.class_name}
                      onChange={(e) => setScheduleForm({ ...scheduleForm, class_name: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600"
                      placeholder="1-A sinf"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Jadval ma'lumotlari (JSON format)
                    </label>
                    <textarea
                      value={scheduleForm.schedule_json}
                      onChange={(e) => setScheduleForm({ ...scheduleForm, schedule_json: e.target.value })}
                      rows={8}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600 font-mono text-sm"
                      placeholder='{"lessons": [{"monday": "Matematika", "tuesday": "Ona tili", ...}]}'
                      required
                    ></textarea>
                    <p className="text-gray-400 text-xs mt-2">
                      Misol: {`{"lessons": [{"monday": "Matematika", "tuesday": "Ona tili", "wednesday": "Ingliz tili", "thursday": "Tarix", "friday": "Fizika", "saturday": "Kimyo"}]}`}
                    </p>
                  </div>
                  <div className="flex space-x-4">
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Saqlash
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowScheduleForm(false)}
                      className="px-6 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
                    >
                      Bekor qilish
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="grid gap-4">
              {schedules.map((item) => (
                <div key={item.id} className="bg-gray-800 rounded-lg p-4 flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-bold text-white">{item.class_name}</h3>
                    <p className="text-gray-400 text-sm">
                      Darslar soni: {Array.isArray(item.schedule_data.lessons) ? item.schedule_data.lessons.length : 0}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteSchedule(item.id)}
                    className="p-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'slider' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Slider boshqaruvi</h2>
              <button
                onClick={() => setShowSliderForm(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus size={20} />
                <span>Slider qo'shish</span>
              </button>
            </div>

            {showSliderForm && (
              <div className="bg-gray-800 rounded-lg p-6 mb-6">
                <h3 className="text-xl font-bold text-white mb-4">Yangi slider</h3>
                <form onSubmit={handleSliderSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Rasm URL</label>
                    <input
                      type="url"
                      value={sliderForm.image_url}
                      onChange={(e) => setSliderForm({ ...sliderForm, image_url: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600"
                      placeholder="https://example.com/image.jpg"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Matn</label>
                    <input
                      type="text"
                      value={sliderForm.caption}
                      onChange={(e) => setSliderForm({ ...sliderForm, caption: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600"
                      placeholder="Slider matni"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">Tartib raqami</label>
                    <input
                      type="number"
                      value={sliderForm.order_index}
                      onChange={(e) => setSliderForm({ ...sliderForm, order_index: parseInt(e.target.value) })}
                      className="w-full px-4 py-2 bg-gray-700 text-white border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-600"
                      min="0"
                      required
                    />
                  </div>
                  <div className="flex space-x-4">
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Saqlash
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowSliderForm(false)}
                      className="px-6 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
                    >
                      Bekor qilish
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="grid gap-4">
              {sliders.map((item) => (
                <div key={item.id} className="bg-gray-800 rounded-lg overflow-hidden flex">
                  <img
                    src={item.image_url}
                    alt={item.caption}
                    className="w-48 h-32 object-cover"
                  />
                  <div className="flex-1 p-4 flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-bold text-white">{item.caption}</h3>
                      <p className="text-gray-400 text-sm">Tartib: {item.order_index}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteSlider(item.id)}
                      className="p-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'statistics' && (
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Statistika boshqaruvi</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {statistics.map((stat) => (
                <div
                  key={stat.id}
                  className="bg-gray-800 rounded-lg p-6 cursor-pointer hover:bg-gray-750 transition-colors"
                  onClick={() => handleUpdateStatistic(stat)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-3xl font-bold text-white mb-2">{stat.value}</h3>
                      <p className="text-gray-400">{stat.label}</p>
                      <p className="text-gray-500 text-sm mt-2">Bosing va o'zgartiring</p>
                    </div>
                    <Edit size={20} className="text-gray-500" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
