import { useEffect, useState } from 'react';
import { Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface NewsItem {
  id: string;
  title: string;
  content: string;
  image_url: string | null;
  created_at: string;
}

export function News() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);

  useEffect(() => {
    loadNews();
  }, []);

  const loadNews = async () => {
    const { data } = await supabase
      .from('news')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) setNews(data);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center">Yangiliklar</h1>

      {selectedNews ? (
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <button
            onClick={() => setSelectedNews(null)}
            className="m-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            ← Orqaga
          </button>
          {selectedNews.image_url && (
            <img
              src={selectedNews.image_url}
              alt={selectedNews.title}
              className="w-full h-96 object-cover"
            />
          )}
          <div className="p-8">
            <div className="flex items-center text-gray-500 mb-4">
              <Calendar size={20} className="mr-2" />
              {new Date(selectedNews.created_at).toLocaleDateString('uz-UZ', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">{selectedNews.title}</h2>
            <div className="prose max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap">
              {selectedNews.content}
            </div>
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {news.length === 0 ? (
            <div className="col-span-full text-center py-12 text-gray-500">
              Hozircha yangiliklar yo'q
            </div>
          ) : (
            news.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
                onClick={() => setSelectedNews(item)}
              >
                {item.image_url && (
                  <img
                    src={item.image_url}
                    alt={item.title}
                    className="w-full h-48 object-cover"
                  />
                )}
                <div className="p-4">
                  <div className="flex items-center text-gray-400 text-xs mb-2">
                    <Calendar size={14} className="mr-1" />
                    {new Date(item.created_at).toLocaleDateString('uz-UZ')}
                  </div>
                  <h3 className="font-bold text-lg mb-2 text-gray-900">{item.title}</h3>
                  <p className="text-gray-600 text-sm line-clamp-3">{item.content}</p>
                  <button className="mt-4 text-blue-600 hover:text-blue-700 font-semibold text-sm">
                    To'liq o'qish →
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
