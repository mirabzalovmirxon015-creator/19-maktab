import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Users, UserCheck, Home as HomeIcon, Award } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Slider {
  id: string;
  image_url: string;
  caption: string;
  order_index: number;
}

interface Statistic {
  id: string;
  key: string;
  value: string;
  label: string;
  icon: string;
}

interface News {
  id: string;
  title: string;
  content: string;
  image_url: string | null;
  created_at: string;
}

const iconMap: Record<string, React.ComponentType<{ size?: number }>> = {
  users: Users,
  'user-check': UserCheck,
  home: HomeIcon,
  award: Award,
};

export function Home({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [sliders, setSliders] = useState<Slider[]>([]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [statistics, setStatistics] = useState<Statistic[]>([]);
  const [news, setNews] = useState<News[]>([]);

  useEffect(() => {
    loadSliders();
    loadStatistics();
    loadNews();
  }, []);

  const loadSliders = async () => {
    const { data } = await supabase
      .from('slider')
      .select('*')
      .eq('active', true)
      .order('order_index');
    if (data) setSliders(data);
  };

  const loadStatistics = async () => {
    const { data } = await supabase
      .from('statistics')
      .select('*')
      .order('created_at');
    if (data) setStatistics(data);
  };

  const loadNews = async () => {
    const { data } = await supabase
      .from('news')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(3);
    if (data) setNews(data);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % sliders.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + sliders.length) % sliders.length);
  };

  useEffect(() => {
    if (sliders.length === 0) return;
    const timer = setInterval(nextSlide, 5000);
    return () => clearInterval(timer);
  }, [sliders.length]);

  return (
    <div>
      {sliders.length > 0 && (
        <div className="relative h-[500px] overflow-hidden">
          {sliders.map((slider, index) => (
            <div
              key={slider.id}
              className={`absolute inset-0 transition-opacity duration-500 ${
                index === currentSlide ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <img
                src={slider.image_url}
                alt={slider.caption}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                <div className="text-center text-white px-4">
                  <h2 className="text-4xl md:text-6xl font-bold mb-4">{slider.caption}</h2>
                </div>
              </div>
            </div>
          ))}
          {sliders.length > 1 && (
            <>
              <button
                onClick={prevSlide}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-white bg-opacity-50 hover:bg-opacity-75 rounded-full p-2 transition-all"
              >
                <ChevronLeft size={32} />
              </button>
              <button
                onClick={nextSlide}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-white bg-opacity-50 hover:bg-opacity-75 rounded-full p-2 transition-all"
              >
                <ChevronRight size={32} />
              </button>
            </>
          )}
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {statistics.map((stat) => {
            const Icon = iconMap[stat.icon] || Award;
            return (
              <div
                key={stat.id}
                className="bg-white rounded-lg shadow-lg p-6 text-center hover:shadow-xl transition-shadow"
              >
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                    <Icon size={32} className="text-blue-600" />
                  </div>
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            );
          })}
        </div>

        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold text-gray-900">So'nggi yangiliklar</h2>
            <button
              onClick={() => onNavigate('news')}
              className="text-blue-600 hover:text-blue-700 font-semibold"
            >
              Barchasini ko'rish →
            </button>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {news.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
                onClick={() => onNavigate('news')}
              >
                {item.image_url && (
                  <img
                    src={item.image_url}
                    alt={item.title}
                    className="w-full h-48 object-cover"
                  />
                )}
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-2 text-gray-900">{item.title}</h3>
                  <p className="text-gray-600 text-sm line-clamp-3">{item.content}</p>
                  <p className="text-gray-400 text-xs mt-2">
                    {new Date(item.created_at).toLocaleDateString('uz-UZ')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
