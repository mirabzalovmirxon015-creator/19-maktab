export interface Database {
  public: {
    Tables: {
      news: {
        Row: {
          id: string;
          title: string;
          content: string;
          image_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          title: string;
          content: string;
          image_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          title?: string;
          content?: string;
          image_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      gallery: {
        Row: {
          id: string;
          image_url: string;
          caption: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          image_url: string;
          caption?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          image_url?: string;
          caption?: string;
          created_at?: string;
        };
      };
      schedule: {
        Row: {
          id: string;
          class_name: string;
          schedule_data: Record<string, unknown>;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          class_name: string;
          schedule_data: Record<string, unknown>;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          class_name?: string;
          schedule_data?: Record<string, unknown>;
          created_at?: string;
          updated_at?: string;
        };
      };
      slider: {
        Row: {
          id: string;
          image_url: string;
          caption: string;
          order_index: number;
          active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          image_url: string;
          caption?: string;
          order_index?: number;
          active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          image_url?: string;
          caption?: string;
          order_index?: number;
          active?: boolean;
          created_at?: string;
        };
      };
      statistics: {
        Row: {
          id: string;
          key: string;
          value: string;
          label: string;
          icon: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          key: string;
          value: string;
          label: string;
          icon?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          key?: string;
          value?: string;
          label?: string;
          icon?: string;
          created_at?: string;
        };
      };
    };
  };
}
