# 19-maktab Web Sayti - To'liq Xususiyatlar

## 🎨 Dizayn

### Rangli palitrasi
- **Asosiy rang**: Ko'k (#2563EB - blue-600)
- **Ikkilamchi rang**: Oq (#FFFFFF)
- **Fon**: Och kulrang (#F3F4F6 - gray-100)
- **Matn**: To'q kulrang (#111827 - gray-900)

### Responsive Dizayn
- 📱 Mobil qurilmalar (320px+)
- 📱 Planshetlar (768px+)
- 💻 Kompyuterlar (1024px+)
- 🖥️ Katta ekranlar (1280px+)

### Animatsiyalar
- Slider avtomatik o'zgarishi (5 soniya)
- Hover effektlar barcha tugmalarda
- Smooth scroll va transition effektlar
- Image zoom gallery-da

## 🏠 Bosh Sahifa

### Slider
- Avtomatik o'zgaruvchi rasmlar
- Oldingi/keyingi tugmalari
- To'liq ekran rasmlar
- Overlay matn bilan

### Statistika Bloklari
- O'quvchilar soni
- O'qituvchilar soni
- Sinflar soni
- Yillik tajriba

### Yangiliklar Preview
- So'nggi 3 ta yangilik
- Rasm va matn ko'rinishi
- "Barchasini ko'rish" tugmasi

## 📰 Yangiliklar Sahifasi

### Ro'yxat Ko'rinishi
- Grid layout (3 ustun)
- Yangilik rasmi
- Sarlavha va qisqa matn
- Sana
- "To'liq o'qish" tugmasi

### To'liq Yangilik
- Katta rasm
- To'liq matn
- Formatlangan sana
- "Orqaga" tugmasi

## 🖼️ Fotogalereya

### Grid Ko'rinish
- 4 ustunli layout
- Hover effekt (zoom)
- Rasm nomi (caption)

### Lightbox
- Katta rasmni ko'rish
- Qora fon (overlay)
- Yopish tugmasi
- Click tashqarida yopish

## 📅 Dars Jadvali

### Sinf Tanlash
- Barcha sinflar ro'yxati
- Aktiv sinf ko'rsatkichi
- Qulay navigatsiya

### Jadval Ko'rinishi
- 7 ustun (Dushanba-Shanba)
- Dars raqamlari
- To'liq jadval
- Horizontal scroll kichik ekranlarda

## 📞 Aloqa Sahifasi

### Aloqa Ma'lumotlari
- Manzil (ikonka bilan)
- Telefon raqamlar
- Email manzillar
- Ish vaqti

### Xabar Formasi
- Ism kiritish
- Telefon raqam
- Email
- Xabar matni
- Yuborish tugmasi

### Google Maps
- Interaktiv xarita
- Maktab manzili

## 🔐 Admin Panel

### Kirish (Login)
- Email/Login maydoni
- Parol maydoni
- "Kirish" tugmasi
- Xato xabarlari
- Gradient fon dizayni

### Dashboard
- Dark mode dizayni
- 5 ta asosiy bo'lim:
  1. Yangiliklar
  2. Fotogalereya
  3. Dars jadvali
  4. Slider
  5. Statistika

### Yangiliklar Boshqaruvi
- Yangilik qo'shish formasi
- Tahrirlash funksiyasi
- O'chirish funksiyasi
- To'liq CRUD operatsiyalari

**Maydonlar:**
- Sarlavha
- Matn (textarea)
- Rasm URL

### Fotogalereya Boshqaruvi
- Rasm qo'shish (URL)
- Caption qo'shish
- Rasmni o'chirish
- Grid ko'rinish

### Dars Jadvali Boshqaruvi
- Sinf nomi
- JSON format jadval
- Misol ko'rsatish
- Jadvalni o'chirish

**JSON Format:**
```json
{
  "lessons": [
    {
      "monday": "Matematika",
      "tuesday": "Ona tili",
      ...
    }
  ]
}
```

### Slider Boshqaruvi
- Rasm URL
- Caption/matn
- Tartib raqami
- Aktiv/noaktiv
- Slider o'chirish

### Statistika Boshqaruvi
- Qiymatlarni yangilash
- Click va prompt orqali
- 4 ta statistika:
  - O'quvchilar
  - O'qituvchilar
  - Sinflar
  - Yillik tajriba

### Xavfsizlik
- Faqat tizimga kirgan foydalanuvchi
- Supabase Auth bilan
- Row Level Security (RLS)
- Session boshqaruvi

## 🔒 Xavfsizlik Xususiyatlari

### Authentication
- Supabase Auth
- Email + Parol
- Session management
- Auto logout

### Database Security
- Row Level Security (RLS)
- Public read access
- Authenticated write access
- SQL injection himoyasi

### Policies
- `SELECT`: Barcha foydalanuvchilar
- `INSERT/UPDATE/DELETE`: Faqat authenticated

## 📱 Mobil Optimizatsiya

### Responsive Header
- Hamburger menu
- Mobil navigatsiya
- Logo ko'rinishi

### Mobil Jadval
- Horizontal scroll
- Touch-friendly
- Yaxshi o'qiluvchi

### Touch Gestures
- Swipe slider-da
- Tap to enlarge gallery-da
- Smooth scrolling

## 🚀 Performance

### Optimizatsiyalar
- Lazy loading rasmlar
- Code splitting
- Minified CSS/JS
- Gzip compression

### Loading States
- Loading indicators
- Error handling
- Empty states

## 🎯 Foydalanish Oson

### Intuitiv Navigatsiya
- Aniq menu nomlari
- Breadcrumbs
- Back tugmalari

### Feedback
- Success messages
- Error messages
- Confirm dialogs
- Loading states

### Accessibility
- Semantic HTML
- ARIA labels (kelgusida)
- Keyboard navigation
- Clear focus states

## 📊 Ma'lumotlar

### Supabase Tables
1. **news** - Yangiliklar
2. **gallery** - Fotogalereya
3. **schedule** - Dars jadvali
4. **slider** - Bosh sahifa slider
5. **statistics** - Statistika

### Real-time Updates
- Yangiliklar avtomatik yangilanadi
- Gallery o'zgarishlari
- Statistika yangiliklari

## 🛠️ Texnik Xususiyatlar

### Frontend
- React 18
- TypeScript
- Tailwind CSS
- Vite

### Backend
- Supabase
- PostgreSQL
- REST API

### Icons
- Lucide React
- 200+ icons

### Forms
- Controlled components
- Form validation
- Error handling

## 📝 Kelajak Rejalar

### Potentsial yangilanishlar:
- File upload (server-ga)
- PDF export (jadvallar)
- Email notifications
- Search funksiyasi
- Multi-language (UZ/RU/EN)
- Student portal
- Teacher accounts
- Online registration
- Payment integration

## 🎓 O'qituvchilar Uchun

### Imkoniyatlar:
- Dars jadvalini ko'rish
- Yangiliklar o'qish
- Maktab haqida ma'lumot

### Kelajakda:
- Shaxsiy cabinet
- Baholar kiritish
- Davomatni belgilash

## 👨‍🎓 O'quvchilar Uchun

### Imkoniyatlar:
- Dars jadvalini ko'rish
- Yangiliklar o'qish
- Fotogalereya
- Maktab bilan bog'lanish

### Kelajakda:
- Shaxsiy cabinet
- Baholarni ko'rish
- Uy vazifalar
- Online darslar

## 👪 Ota-onalar Uchun

### Imkoniyatlar:
- Maktab haqida ma'lumot
- Yangiliklar
- Bog'lanish
- Dars jadvali

### Kelajakda:
- Farzandning baholarini ko'rish
- Davomatni kuzatish
- O'qituvchilar bilan aloqa
- To'lovlar

---

Bu loyiha 19-maktab uchun professional, zamonaviy va foydalanish uchun qulay web-sayt yaratish maqsadida ishlab chiqilgan.
