# 19-maktab Rasmiy Web Sayti

Zamonaviy, professional va mobilga mos web-sayt.

## Xususiyatlar

### Foydalanuvchilar uchun sahifalar

1. **Bosh sahifa**
   - Avtomatik o'zgaruvchi slider
   - Maktab statistikasi (o'quvchilar, o'qituvchilar, sinflar)
   - So'nggi yangiliklar ko'rinishi

2. **Biz haqimizda**
   - Maktab tarixi va maqsadlari
   - Afzalliklar va imkoniyatlar

3. **Yangiliklar**
   - Barcha yangiliklar ro'yxati
   - To'liq yangilik ko'rish

4. **Fotogalereya**
   - Rasm galereyasi
   - Katta rasmda ko'rish (lightbox)

5. **Dars jadvali**
   - Sinflar bo'yicha jadvallar
   - Interaktiv jadval ko'rinishi

6. **Aloqa**
   - Maktab manzili, telefon, email
   - Google Maps xarita
   - Xabar yuborish formasi

### Admin Panel

Direktor uchun maxsus dark mode admin panel:

1. **Yangiliklar boshqaruvi**
   - Yangilik qo'shish
   - Yangilikni tahrirlash
   - Yangilikni o'chirish

2. **Fotogalereya boshqaruvi**
   - Rasm yuklash (URL orqali)
   - Rasmlarni o'chirish

3. **Dars jadvali boshqaruvi**
   - Jadval qo'shish (JSON format)
   - Jadvalni o'chirish

4. **Slider boshqaruvi**
   - Slider rasm qo'shish
   - Slider o'chirish
   - Tartib raqamini belgilash

5. **Statistika boshqaruvi**
   - Statistik ma'lumotlarni yangilash
   - O'quvchilar, o'qituvchilar, sinflar soni

## Texnologiyalar

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Build Tool**: Vite
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **Icons**: Lucide React

## O'rnatish

1. Paketlarni o'rnatish:
```bash
npm install
```

2. Direktor hisobini yaratish (SETUP.md faylini ko'ring)

3. Loyihani ishga tushirish:
```bash
npm run dev
```

## Direktor kirish ma'lumotlari

Admin panelga kirish uchun direktor hisobini Supabase Dashboard orqali yaratish kerak:

- **Email**: `director@19maktab.uz`
- **Parol**: `19!maktab!`

Batafsil yo'riqnoma uchun `SETUP.md` faylini o'qing.

## Loyiha strukturasi

```
src/
├── components/          # Komponentlar
│   ├── Header.tsx      # Navigatsiya
│   └── Footer.tsx      # Footer
├── pages/              # Sahifalar
│   ├── Home.tsx        # Bosh sahifa
│   ├── About.tsx       # Biz haqimizda
│   ├── News.tsx        # Yangiliklar
│   ├── Gallery.tsx     # Fotogalereya
│   ├── Schedule.tsx    # Dars jadvali
│   ├── Contact.tsx     # Aloqa
│   ├── Login.tsx       # Kirish sahifasi
│   └── Admin.tsx       # Admin panel
├── contexts/           # React Context
│   └── AuthContext.tsx # Autentifikatsiya
├── lib/                # Kutubxonalar
│   └── supabase.ts     # Supabase client
├── types/              # TypeScript types
│   └── database.ts     # Database types
├── App.tsx             # Asosiy komponent
└── main.tsx           # Entry point
```

## Dizayn

- **Ranglari**: Ko'k va oq (professional)
- **Responsive**: Barcha qurilmalar uchun moslashgan
- **Admin Panel**: Dark mode dizayni
- **Animatsiyalar**: Smooth transitions va hover effektlar

## Ma'lumotlar bazasi

Supabase PostgreSQL ma'lumotlar bazasida quyidagi jadvallar:

- `news` - Yangiliklar
- `gallery` - Fotogalereya
- `schedule` - Dars jadvali
- `slider` - Bosh sahifa slider
- `statistics` - Statistika ma'lumotlari

Barcha jadvallar Row Level Security (RLS) bilan himoyalangan.

## Build

Ishlab chiqarish uchun build:

```bash
npm run build
```

Build natijasi `dist/` papkasida saqlanadi.

## Muallif

19-maktab uchun ishlab chiqilgan professional web-sayt.
