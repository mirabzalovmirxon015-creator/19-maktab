/*
  # School 19 Database Schema

  1. New Tables
    - `news`
      - `id` (uuid, primary key)
      - `title` (text, news title)
      - `content` (text, news content)
      - `image_url` (text, news image)
      - `created_at` (timestamptz, creation timestamp)
      - `updated_at` (timestamptz, update timestamp)
    
    - `gallery`
      - `id` (uuid, primary key)
      - `image_url` (text, image URL)
      - `caption` (text, image caption)
      - `created_at` (timestamptz, creation timestamp)
    
    - `schedule`
      - `id` (uuid, primary key)
      - `class_name` (text, class/grade name)
      - `schedule_data` (jsonb, schedule details)
      - `created_at` (timestamptz, creation timestamp)
      - `updated_at` (timestamptz, update timestamp)
    
    - `slider`
      - `id` (uuid, primary key)
      - `image_url` (text, slider image URL)
      - `caption` (text, slider caption)
      - `order_index` (integer, display order)
      - `active` (boolean, whether slider is active)
      - `created_at` (timestamptz, creation timestamp)
    
    - `statistics`
      - `id` (uuid, primary key)
      - `key` (text, unique identifier)
      - `value` (text, statistic value)
      - `label` (text, display label)
      - `icon` (text, icon name)
      - `created_at` (timestamptz, creation timestamp)

  2. Security
    - Enable RLS on all tables
    - Public can read all data
    - Only authenticated users can insert/update/delete
*/

-- Create news table
CREATE TABLE IF NOT EXISTS news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create gallery table
CREATE TABLE IF NOT EXISTS gallery (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url text NOT NULL,
  caption text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create schedule table
CREATE TABLE IF NOT EXISTS schedule (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_name text NOT NULL UNIQUE,
  schedule_data jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create slider table
CREATE TABLE IF NOT EXISTS slider (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url text NOT NULL,
  caption text DEFAULT '',
  order_index integer DEFAULT 0,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create statistics table
CREATE TABLE IF NOT EXISTS statistics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  value text NOT NULL,
  label text NOT NULL,
  icon text DEFAULT 'award',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE news ENABLE ROW LEVEL SECURITY;
ALTER TABLE gallery ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE slider ENABLE ROW LEVEL SECURITY;
ALTER TABLE statistics ENABLE ROW LEVEL SECURITY;

-- Policies for news
CREATE POLICY "Anyone can view news"
  ON news FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert news"
  ON news FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update news"
  ON news FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete news"
  ON news FOR DELETE
  TO authenticated
  USING (true);

-- Policies for gallery
CREATE POLICY "Anyone can view gallery"
  ON gallery FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert gallery"
  ON gallery FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update gallery"
  ON gallery FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete gallery"
  ON gallery FOR DELETE
  TO authenticated
  USING (true);

-- Policies for schedule
CREATE POLICY "Anyone can view schedule"
  ON schedule FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert schedule"
  ON schedule FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update schedule"
  ON schedule FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete schedule"
  ON schedule FOR DELETE
  TO authenticated
  USING (true);

-- Policies for slider
CREATE POLICY "Anyone can view active sliders"
  ON slider FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert slider"
  ON slider FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update slider"
  ON slider FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete slider"
  ON slider FOR DELETE
  TO authenticated
  USING (true);

-- Policies for statistics
CREATE POLICY "Anyone can view statistics"
  ON statistics FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert statistics"
  ON statistics FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update statistics"
  ON statistics FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete statistics"
  ON statistics FOR DELETE
  TO authenticated
  USING (true);

-- Insert default data
INSERT INTO statistics (key, value, label, icon) VALUES
  ('students', '1250', 'O''quvchilar', 'users'),
  ('teachers', '85', 'O''qituvchilar', 'user-check'),
  ('classes', '42', 'Sinflar', 'home'),
  ('years', '25', 'Yillik tajriba', 'award')
ON CONFLICT (key) DO NOTHING;

INSERT INTO slider (image_url, caption, order_index, active) VALUES
  ('https://images.pexels.com/photos/289737/pexels-photo-289737.jpeg?auto=compress&cs=tinysrgb&w=1920', 'Zamonaviy ta''lim muhiti', 1, true),
  ('https://images.pexels.com/photos/1370296/pexels-photo-1370296.jpeg?auto=compress&cs=tinysrgb&w=1920', 'Sifatli bilim - yorqin kelajak', 2, true),
  ('https://images.pexels.com/photos/1720186/pexels-photo-1720186.jpeg?auto=compress&cs=tinysrgb&w=1920', 'Malakali pedagog kadrlar', 3, true)
ON CONFLICT DO NOTHING;